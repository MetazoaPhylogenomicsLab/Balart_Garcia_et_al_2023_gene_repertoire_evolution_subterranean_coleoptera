# Process/plot Gains & Losses / Expansion/Contractions across OGs for each branch, only for Significant OGs

gains<-read.table("Gains_table.txt", h=F, row.names = 1, skip = 1)
head(gains)[,1:20]

loss<-read.table("Loss_table.txt", h=F, row.names = 1, skip = 1)
head(loss)[,1:20]

#get OG names (order in gain/loss tables is alphabetical)
ogs<-read.table("OGs_list_all.txt")
ogs<-ogs$V1[order(ogs$V1)]
head(ogs)
colnames(gains)<-colnames(loss)<-ogs

# remove species specific innovations
#head(specific)
#gains<-gains[,!colnames(gains)%in%row.names(specific)]
#head(gains)[,1:20]
#loss<-loss[,!colnames(loss)%in%row.names(specific)]
#head(loss)[,1:20]
#dim(gains);dim(loss)

#transform to binary
gains_pa <- sign(gains)
head(gains_pa)[,1:20]

loss_pa <- sign(loss)
head(loss_pa)[,1:20]

#Minimum number of total(across all OGs) copies gains/losses per branch in significant OGs ##(excluding species specific)
gainsbranchcopies<-rowSums(gains)
head(gainsbranchcopies)
lossbranchcopies<-rowSums(loss)
head(lossbranchcopies)
OGs_gainslossbranchcopies<-cbind("TotalCopyGains"=gainsbranchcopies, "TotalCopyLosses"=lossbranchcopies)
head(OGs_gainslossbranchcopies)

#Number of OGs with gains/losses per branch in significant OGs ## (excluding species specific)
gainsbranch<-rowSums(gains_pa)
head(gainsbranch)
lossbranch<-rowSums(loss_pa)
head(lossbranch)
OGs_gainslossbranch<-cbind("OGsWithGains"=gainsbranch, "OGsWithLosses"=lossbranch)
head(OGs_gainslossbranch)

# merge two tables
branchdynamics<-cbind(OGs_gainslossbranch, OGs_gainslossbranchcopies)
head(branchdynamics)
plot(branchdynamics[,2], branchdynamics[,4])

write.table(branchdynamics, file="OGs_GL_dynamics_per_branch.txt", sep="\t", quote=F)

###
install.packages("ape")
require(ape)
tree<-read.tree("tree_node_ids.txt")
plot(tree, cex=0.6, no.margin = T)
nodelabels(tree$node.label, pos=2, frame="none", col="red")
nodelabels(unique(tree$edge[,1]), frame="none", col="blue")
nodelabels(frame="none", col="green", pos=4)
tiplabels(cex=0.8)

nodematch<-cbind("Badirate"=as.integer(tree$node.label), "phylo"=unique(tree$edge[,1]))
head(nodematch)

# remap badirate nodes to phylo format
branchdynamics<-cbind(OGs_gainslossbranch, OGs_gainslossbranchcopies)
branchdynamics<-cbind("ParentNode"=as.integer(sub("->.*","",row.names(branchdynamics))),
                      "ChildNode"=as.integer(sub(".*->","",row.names(branchdynamics))),branchdynamics)
branchdynamics<-as.data.frame(branchdynamics)
head(branchdynamics)

branchdynamics<-cbind("ParentNodePhylo"=nodematch[match(branchdynamics[,1],nodematch[,1]),2], branchdynamics)
head(branchdynamics)
#tail(branchdynamics)

indx <- branchdynamics[,3]%in%nodematch[,1] #FALSE are tips
branchdynamics<-cbind(branchdynamics[,1:2], "ChildNodePhylo"=branchdynamics[,3], branchdynamics[,3:7]) #duplicate column
branchdynamics[indx, 3] <- paste0("NODE",nodematch[match(branchdynamics[indx,3], nodematch[,1]),2]) #mark nodes
head(branchdynamics, n=15)

#tips
# tips<-tree$edge[tree$edge[,2]<104,]
# head(tips)
# 
# branchdynamics[!grepl("NO",branchdynamics[,3]),3] <- tips[match(branchdynamics[!indx,1], tips[,1]),2]
branchdynamics[,3]<-tree$edge[,2]
head(branchdynamics, n=10)

branchdynamics_internal<-branchdynamics[branchdynamics$ParentNodePhylo>41,]

tree_gains<-tree
tree_gains$node.label <- branchdynamics_internal$TotalCopyGains[match(tree$node.label,branchdynamics_internal$ChildNode)]
write.tree(tree_gains, "tree_gains.nwk")

tree_losses<-tree
tree_losses$node.label <- branchdynamics_internal$TotalCopyLosses[match(tree$node.label,branchdynamics_internal$ChildNode)]
write.tree(tree_losses, "tree_losses.nwk")



write.table(branchdynamics, file="OGs_GL_dynamics_per_branch.txt", sep="\t", quote=F)

# PLOT
require(ggplot2)
require(ggtree)
library(dplyr)
library(data.table)
library(viridis)
library(RColorBrewer)
library(ggtreeExtra)
library(ggnewscale)

tree <- read.tree("../../../post_times_tree.nwk")

#data must have a "node" column with labels matching the tree labels
row.names(branchdynamics)<-NULL
head(branchdynamics, n=10)

brdyn<-branchdynamics
brdyn<-cbind("node"=brdyn$ChildNodePhylo,brdyn[,5:8])
head(brdyn)

p <- ggtree(tree, alpha=0.7, layout = "circular") %<+% brdyn

p2 <- p + geom_nodelab(aes(label=OGsWithGains, x=branch, color=OGsWithGains), size=3,
                    fontface="bold", nudge_y = 0.9) +
  scale_color_viridis(option = "magma", direction = -1,end = 0.8) + new_scale_color() +
  geom_nodelab(aes(label=OGsWithLosses, x=branch, color=OGsWithLosses), size=3,
                    fontface="bold", nudge_y = -0.9) +
  scale_color_viridis(option = "viridis", direction = -1,end = 1)
p2




