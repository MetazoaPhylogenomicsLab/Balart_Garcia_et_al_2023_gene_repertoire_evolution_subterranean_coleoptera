# A treemap R script produced by the Revigo server at http://revigo.irb.hr/
# If you found Revigo useful in your work, please cite the following reference:
# Supek F et al. "REVIGO summarizes and visualizes long lists of Gene Ontology
# terms" PLoS ONE 2011. doi:10.1371/journal.pone.0021800

# author: Anton Kratz <anton.kratz@gmail.com>, RIKEN Omics Science Center, Functional Genomics Technology Team, Japan
# created: Fri, Nov 02, 2012  7:25:52 PM
# last change: Fri, Nov 09, 2012  3:20:01 PM

# -----------------------------------------------------------------------------
# If you don't have the treemap package installed, uncomment the following line:
# install.packages( "treemap" );
library(treemap) 								# treemap package by Martijn Tennekes

# Set the working directory if necessary
# setwd("C:/Users/username/workingdir");

# --------------------------------------------------------------------------
# Here is your data from Revigo. Scroll down for plot configuration options.

revigo.names <- c("term_ID","description","frequency","value","uniqueness","dispensability","representative");
revigo.data <- rbind(c("GO:0001503","ossification",1.55442651252009,3.3777859770337,0.825806852076865,0,"ossification"),
c("GO:0001763","morphogenesis of a branching structure",0.519300675090878,2.0584885673656,0.759878114138484,0.4022394,"ossification"),
c("GO:0007384","specification of segmental identity, thorax",0.0259650337545439,2.06499684854635,0.763532723497416,0.40614406,"ossification"),
c("GO:0007538","primary sex determination",0.129825168772719,2.0584885673656,0.763574951590529,0.31121054,"ossification"),
c("GO:0007586","digestion",0.138480180024234,2.0584885673656,0.858928242944229,0.16131057,"ossification"),
c("GO:0014016","neuroblast differentiation",0.424095551324217,2.08777794346758,0.706027911375895,0.28009462,"ossification"),
c("GO:0021984","adenohypophysis development",2.11136773133837,2.06499684854635,0.578957306997321,0.47448375,"ossification"),
c("GO:0030282","bone mineralization",0.404711889075257,2.06499684854635,0.714529284677766,0.39828681,"ossification"),
c("GO:0030903","notochord development",0.334148623087204,2.06499684854635,0.688622564625997,0.49181594,"ossification"),
c("GO:0031016","pancreas development",1.16770084732145,2.03857890593355,0.74323665386711,0.49314296,"ossification"),
c("GO:0035052","dorsal vessel aortic cell fate commitment",0.00865501125151463,2.21253952548158,0.736967564024011,0.44890616,"ossification"),
c("GO:0035107","appendage morphogenesis",2.78691362298771,2.06499684854635,0.699676120866945,0.35594207,"ossification"),
c("GO:0046692","sperm competition",0.190410247533322,2.06499684854635,0.801483193363802,0.16623682,"ossification"),
c("GO:0048469","cell maturation",1.43673186775143,2.06499684854635,0.755274822909386,0.36871198,"ossification"),
c("GO:0048645","animal organ formation",0.389475506318158,2.06499684854635,0.740584022475249,0.49179157,"ossification"),
c("GO:0048736","appendage development",2.85615371299983,2.06499684854635,0.713178806422168,0.38242226,"ossification"),
c("GO:0048863","stem cell differentiation",0.24234031504241,2.06499684854635,0.811425919172526,0.28955094,"ossification"),
c("GO:0050905","neuromuscular process",0.147135191275749,2.12959609472097,0.819075392827606,0.16222576,"ossification"),
c("GO:0060479","lung cell differentiation",0.842251571656959,2.06499684854635,0.63866938678835,0.36354652,"ossification"),
c("GO:0060795","cell fate commitment involved in formation of primary germ layer",0.164445213778778,2.21253952548158,0.690926240544376,0.16393211,"ossification"),
c("GO:0032526","response to retinoic acid",0.00865501125151463,2.08777794346758,0.941574368292634,0,"response to retinoic acid"),
c("GO:0007173","epidermal growth factor receptor signaling pathway",0.22503029253938,2.06499684854635,0.858086169778394,0.19785086,"response to retinoic acid"),
c("GO:0019932","second-messenger-mediated signaling",0.484680630084819,2.040481623027,0.855978479695562,0.34746759,"response to retinoic acid"),
c("GO:0042060","wound healing",0.631815821360568,2.06499684854635,0.920597927649325,0.21807076,"response to retinoic acid"),
c("GO:0070482","response to oxygen levels",0.649125843863597,2.06499684854635,0.878835439488023,0.15306116,"response to retinoic acid"),
c("GO:0071454","cellular response to anoxia",0.0173100225030293,2.13253251214095,0.88477948061316,0.4693628,"response to retinoic acid"),
c("GO:0046717","acid secretion",0.00865501125151463,2.13253251214095,0.993651134498189,0,"acid secretion"),
c("GO:0015718","monocarboxylic acid transport",0.328890427557556,2.05060999335509,0.993651134498189,0.2003077,"acid secretion"),
c("GO:1905939","regulation of gonad development",0.410706833998146,3.44977164694491,0.809899173175832,0,"regulation of gonad development"),
c("GO:0010817","regulation of hormone levels",0.952051237666609,2.17005330405836,0.943985614869286,0.10021529,"regulation of gonad development"),
c("GO:0032330","regulation of chondrocyte differentiation",0.306045058015852,2.06499684854635,0.854475904632018,0.47454499,"regulation of gonad development"),
c("GO:0048871","multicellular organismal homeostasis",0.649125843863597,2.13253251214095,0.789462846768034,0.39689466,"regulation of gonad development"),
c("GO:1905332","positive regulation of morphogenesis of an epithelium",0.168266540374226,2.06499684854635,0.786676518996777,0.45065552,"regulation of gonad development"));

stuff <- data.frame(revigo.data);
names(stuff) <- revigo.names;

stuff$value <- as.numeric( as.character(stuff$value) );
stuff$frequency <- as.numeric( as.character(stuff$frequency) );
stuff$uniqueness <- as.numeric( as.character(stuff$uniqueness) );
stuff$dispensability <- as.numeric( as.character(stuff$dispensability) );

# by default, outputs to a PDF file
pdf( file="revigo_treemap.pdf", width=16, height=9 ) # width and height are in inches

# check the tmPlot command documentation for all possible parameters - there are a lot more
treemap(
  stuff,
  index = c("representative","description"),
  vSize = "value",
  type = "categorical",
  vColor = "representative",
  title = "Revigo TreeMap",
  inflate.labels = FALSE,      # set this to TRUE for space-filling group labels - good for posters
  lowerbound.cex.labels = 0,   # try to draw as many labels as possible (still, some small squares may not get a label)
  bg.labels = "#CCCCCCAA",   # define background color of group labels
								 # "#CCCCCC00" is fully transparent, "#CCCCCCAA" is semi-transparent grey, NA is opaque
  position.legend = "none"
)

dev.off()

