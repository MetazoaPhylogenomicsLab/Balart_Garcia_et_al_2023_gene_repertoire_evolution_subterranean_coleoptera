# A treemap R script produced by the Revigo server at http://revigo.irb.hr/
# If you found Revigo useful in your work, please cite the following reference:
# Supek F et al. "REVIGO summarizes and visualizes long lists of Gene Ontology
# terms" PLoS ONE 2011. doi:10.1371/journal.pone.0021800

# author: Anton Kratz <anton.kratz@gmail.com>, RIKEN Omics Science Center, Functional Genomics Technology Team, Japan
# created: Fri, Nov 02, 2012  7:25:52 PM
# last change: Fri, Nov 09, 2012  3:20:01 PM

# -----------------------------------------------------------------------------
# If you don't have the treemap package installed, uncomment the following line:
# install.packages( "treemap" );
library(treemap) 								# treemap package by Martijn Tennekes

# Set the working directory if necessary
# setwd("C:/Users/username/workingdir");

# --------------------------------------------------------------------------
# Here is your data from Revigo. Scroll down for plot configuration options.

revigo.names <- c("term_ID","description","frequency","value","uniqueness","dispensability","representative");
revigo.data <- rbind(c("GO:0000281","mitotic cytokinesis",0.441405573827246,2.65757731917779,0.977085429110794,0,"mitotic cytokinesis"),
c("GO:0007492","endoderm development",0.0778951012636316,3.22184874961636,0.853185933260432,0,"endoderm development"),
c("GO:0031128","developmental induction",0.00865501125151463,2.93554201077308,0.897197168416254,0.13311382,"endoderm development"),
c("GO:0030099","myeloid cell differentiation",0.00865501125151463,2.30891850787703,0.821610080116883,0.14036495,"endoderm development"),
c("GO:0040003","chitin-based cuticle development",1.72234723905141,3.1765257708297,0.779618925968128,0.20659113,"endoderm development"),
c("GO:0001503","ossification",1.55701509343569,3.09582563171584,0.881316435818404,0.21078679,"endoderm development"),
c("GO:0048863","stem cell differentiation",0.24234031504241,2.53910215724345,0.849354307982435,0.21796983,"endoderm development"),
c("GO:0031099","regeneration",0.268305348796953,2.18309616062434,0.858965125389722,0.2321869,"endoderm development"),
c("GO:0048865","stem cell fate commitment",0.0519300675090878,2.21824462534753,0.864628542697043,0.24479221,"endoderm development"),
c("GO:0046660","female sex differentiation",0.199065258784836,2.30891850787703,0.81657870460797,0.26544092,"endoderm development"),
c("GO:0021700","developmental maturation",1.63579712653626,2.03198428600636,0.83991330531959,0.2688869,"endoderm development"),
c("GO:0003007","heart morphogenesis",0.320235416306041,3.1765257708297,0.745743206373685,0.27831113,"endoderm development"),
c("GO:0048762","mesenchymal cell differentiation",0.0173100225030293,2.84466396253494,0.826426900892584,0.28440618,"endoderm development"),
c("GO:0061061","muscle structure development",1.7742773065605,2.07987667370928,0.830383514730351,0.28638093,"endoderm development"),
c("GO:0009950","dorsal/ventral axis specification",0.623160810109053,2.49757288001557,0.79516457618523,0.29858391,"endoderm development"),
c("GO:0014706","striated muscle tissue development",0.0865501125151463,2.2839966563652,0.846727976199038,0.31413188,"endoderm development"),
c("GO:0060485","mesenchyme development",0.0865501125151463,2.60906489289662,0.817917887584122,0.32017764,"endoderm development"),
c("GO:0001763","morphogenesis of a branching structure",0.519300675090878,2.84466396253494,0.809437031528299,0.32315234,"endoderm development"),
c("GO:0048469","cell maturation",1.43673186775143,2.10568393731556,0.813859847800869,0.32396764,"endoderm development"),
c("GO:0060537","muscle tissue development",0.121170157521205,2.20971483596676,0.847896886954567,0.32421282,"endoderm development"),
c("GO:0042335","cuticle development",2.01661762160291,3.14266750356873,0.78629290715552,0.34260632,"endoderm development"),
c("GO:0060541","respiratory system development",2.13778777912411,2.98296666070122,0.759360371959803,0.38820988,"endoderm development"),
c("GO:0048598","embryonic morphogenesis",2.02527263285442,2.82681373158773,0.751924633860479,0.38822103,"endoderm development"),
c("GO:0002165","instar larval or pupal development",4.71698113207547,2.56863623584101,0.754545228006839,0.39553272,"endoderm development"),
c("GO:0060560","developmental growth involved in morphogenesis",0.675090877618141,2.21538270736712,0.823408030372222,0.3996686,"endoderm development"),
c("GO:0007591","molting cycle, chitin-based cuticle",0.735675956378743,4.08039897621589,0.873751164118524,0,"molting cycle, chitin-based cuticle"),
c("GO:0007586","digestion",0.138480180024234,3.1765257708297,0.90566950875896,0.15081218,"molting cycle, chitin-based cuticle"),
c("GO:0050905","neuromuscular process",0.147135191275749,2.84466396253494,0.88735864295232,0.15161183,"molting cycle, chitin-based cuticle"),
c("GO:0042303","molting cycle",0.735675956378743,3.53760200210104,0.890119404305756,0.17644928,"molting cycle, chitin-based cuticle"),
c("GO:0008202","steroid metabolic process",0.545265708845421,3.1765257708297,0.966401747173822,0,"steroid metabolic process"),
c("GO:0016311","dephosphorylation",1.41076683399688,3.14266750356873,0.959009105721046,0.11022196,"steroid metabolic process"),
c("GO:0042180","cellular ketone metabolic process",0.519300675090878,2.8153085691824,0.967383801539305,0.14180521,"steroid metabolic process"),
c("GO:0006629","lipid metabolic process",4.82949627834516,2.67985371388895,0.978934268653987,0.15635202,"steroid metabolic process"),
c("GO:1901615","organic hydroxy compound metabolic process",1.67041717154232,2.2839966563652,0.982264188471929,0.16448236,"steroid metabolic process"),
c("GO:0044262","cellular carbohydrate metabolic process",0.865501125151463,2.29413628771608,0.972243434737276,0.16563734,"steroid metabolic process"),
c("GO:1901137","carbohydrate derivative biosynthetic process",2.7782586117362,2.64975198166584,0.9716598284599,0.17713482,"steroid metabolic process"),
c("GO:0005975","carbohydrate metabolic process",2.18106283538169,2.61083391563547,0.980952652562284,0.18796764,"steroid metabolic process"),
c("GO:1901135","carbohydrate derivative metabolic process",4.44867578327852,2.65757731917779,0.979957603545256,0.19070995,"steroid metabolic process"),
c("GO:0009812","flavonoid metabolic process",4.55893021643056,2.09745322068601,0.979892633734545,0.19147302,"steroid metabolic process"),
c("GO:0006793","phosphorus metabolic process",7.31348450752986,2.51855737149769,0.965520702099224,0.19634958,"steroid metabolic process"),
c("GO:0044281","small molecule metabolic process",7.02786913622988,2.08460016478773,0.98046303407112,0.19809343,"steroid metabolic process"),
c("GO:0045730","respiratory burst",8.81988798294839,2.29413628771608,0.979824472180924,0.20701404,"steroid metabolic process"),
c("GO:0010817","regulation of hormone levels",0.952051237666609,4.74957999769111,0.904065973237502,0,"regulation of hormone levels"),
c("GO:0060341","regulation of cellular localization",1.02994633893024,3.14266750356873,0.834465229034784,0.11019757,"regulation of hormone levels"),
c("GO:0043086","negative regulation of catalytic activity",1.46269690150597,2.79048498545737,0.912334899316139,0.1155746,"regulation of hormone levels"),
c("GO:2000243","positive regulation of reproductive process",0.588540765102995,2.97881070093006,0.891437799277549,0.12643017,"regulation of hormone levels"),
c("GO:2001053","regulation of mesenchymal cell apoptotic process",0.244504067855288,2.16621562534352,0.928095026106786,0.12944776,"regulation of hormone levels"),
c("GO:0051302","regulation of cell division",0.3548554613121,2.15366288787019,0.925815413593108,0.13416706,"regulation of hormone levels"),
c("GO:2000241","regulation of reproductive process",1.0645663839363,2.80687540164554,0.922312029201119,0.13464798,"regulation of hormone levels"),
c("GO:0040012","regulation of locomotion",1.04725636143327,2.65757731917779,0.92243173804143,0.13489456,"regulation of hormone levels"),
c("GO:0070372","regulation of ERK1 and ERK2 cascade",0.398130517569673,2.58004425151024,0.907819054762736,0.13569535,"regulation of hormone levels"),
c("GO:0030155","regulation of cell adhesion",0.458715596330275,2.09745322068601,0.92415799140893,0.13762517,"regulation of hormone levels"),
c("GO:0007088","regulation of mitotic nuclear division",0.476025618833304,2.38933983691012,0.916461003575213,0.1381389,"regulation of hormone levels"),
c("GO:0032879","regulation of localization",4.82084126709365,2.30891850787703,0.909444342778275,0.16208378,"regulation of hormone levels"),
c("GO:0002682","regulation of immune system process",2.15509780162714,2.03198428600636,0.916787905022656,0.17872424,"regulation of hormone levels"),
c("GO:0050865","regulation of cell activation",2.53764740447633,2.15490195998574,0.910892247138719,0.18307901,"regulation of hormone levels"),
c("GO:2000648","positive regulation of stem cell proliferation",0.0346200450060585,2.26921772433361,0.916260633959733,0.2373665,"regulation of hormone levels"),
c("GO:0045785","positive regulation of cell adhesion",0.207720270036351,2.7851561519523,0.903108438240993,0.27496403,"regulation of hormone levels"),
c("GO:0042753","positive regulation of circadian rhythm",0.216375281287866,2.10568393731556,0.910180043588466,0.27595989,"regulation of hormone levels"),
c("GO:0001508","action potential",0.0605850787606024,2.10568393731556,0.919253515534668,0.31886661,"regulation of hormone levels"),
c("GO:0007204","positive regulation of cytosolic calcium ion concentration",0.129825168772719,2.60032627851896,0.918710644312542,0.34037091,"regulation of hormone levels"),
c("GO:0042445","hormone metabolic process",0.631815821360568,3.03810452633215,0.877937206960858,0.39579085,"regulation of hormone levels"),
c("GO:0048871","multicellular organismal homeostasis",0.649125843863597,2.61083391563547,0.801427163632966,0.39689466,"regulation of hormone levels"),
c("GO:0015711","organic anion transport",1.1857365414575,3.1765257708297,0.953585978585884,0,"organic anion transport"),
c("GO:0007097","nuclear migration",0.294270382551497,2.39685562737982,0.961775181602648,0.29416027,"organic anion transport"),
c("GO:0098739","import across plasma membrane",0.346200450060585,2.014573525917,0.960609883350103,0.29889326,"organic anion transport"),
c("GO:0034502","protein localization to chromosome",0.155790202527263,2.17069622716898,0.968841043573316,0.3649513,"organic anion transport"),
c("GO:0033993","response to lipid",0.46737060758179,3.35261702988538,0.899375470883956,0,"response to lipid"),
c("GO:0009719","response to endogenous stimulus",1.50597195776355,3.15242734085789,0.938682983929708,0.23038868,"response to lipid"),
c("GO:0009620","response to fungus",0.57988575385148,2.28567024025477,0.938278609782459,0.23570622,"response to lipid"),
c("GO:1905114","cell surface receptor signaling pathway involved in cell-cell signaling",0.848191102648433,2.68613277963085,0.841107060566037,0.24570373,"response to lipid"),
c("GO:0009611","response to wounding",0.874156136402977,3.05207638016827,0.94000365485577,0.24653287,"response to lipid"),
c("GO:0051606","detection of stimulus",2.46667820668167,2.60906489289662,0.935519637076343,0.27891379,"response to lipid"),
c("GO:0071214","cellular response to abiotic stimulus",0.588540765102995,2.60906489289662,0.910307821880119,0.31832973,"response to lipid"),
c("GO:0104004","cellular response to environmental stimulus",0.588540765102995,2.60906489289662,0.926056478477429,0.31832973,"response to lipid"),
c("GO:0071229","cellular response to acid chemical",0.129825168772719,2.79317412396815,0.90531359204198,0.33884053,"response to lipid"),
c("GO:0009410","response to xenobiotic stimulus",0.155790202527263,2.62893213772826,0.926722162052409,0.34406257,"response to lipid"),
c("GO:0001101","response to acid chemical",0.233685303790895,2.70114692359029,0.92425536274799,0.35627337,"response to lipid"),
c("GO:0019932","second-messenger-mediated signaling",0.484680630084819,2.20971483596676,0.854716717453317,0.39311895,"response to lipid"),
c("GO:0043473","pigmentation",0.631815821360568,2.51855737149769,1,0,"pigmentation"),
c("GO:0110148","biomineralization",15.0194737753159,2.57348873863542,1,0,"biomineralization"),
c("GO:0120031","plasma membrane bounded cell projection assembly",1.46269690150597,2.64975198166584,0.968773434078996,0.02608901,"plasma membrane bounded cell projection assembly"),
c("GO:1990255","subsynaptic reticulum organization",0.0346200450060585,2.58335949266172,0.981143061599321,0.18072743,"plasma membrane bounded cell projection assembly"),
c("GO:0043062","extracellular structure organization",0.701055911372685,2.24488773360493,0.978419128586667,0.23991554,"plasma membrane bounded cell projection assembly"),
c("GO:0007015","actin filament organization",1.08187640643933,2.15366288787019,0.973564090653117,0.25255166,"plasma membrane bounded cell projection assembly"),
c("GO:0045229","external encapsulating structure organization",1.27228665397265,2.27327279097343,0.977115229448294,0.2565626,"plasma membrane bounded cell projection assembly"),
c("GO:0030856","regulation of epithelial cell differentiation",0.0259650337545439,2.76700388960785,0.887978595137704,0.07878252,"regulation of epithelial cell differentiation"),
c("GO:0001819","positive regulation of cytokine production",0.00865501125151463,2.16685288808721,0.898103175968247,0.3224901,"regulation of epithelial cell differentiation"),
c("GO:0019218","regulation of steroid metabolic process",0.0778951012636316,2.8153085691824,0.917597098448381,0.08611002,"regulation of steroid metabolic process"),
c("GO:1902930","regulation of alcohol biosynthetic process",0.00865501125151463,2.5654310959658,0.937459912562643,0.15360782,"regulation of steroid metabolic process"),
c("GO:0019216","regulation of lipid metabolic process",0.441405573827246,2.39685562737982,0.919659975093623,0.22895064,"regulation of steroid metabolic process"),
c("GO:0045936","negative regulation of phosphate metabolic process",0.432750562575731,2.29756946355447,0.893914008340457,0.23343366,"regulation of steroid metabolic process"),
c("GO:0034248","regulation of cellular amide metabolic process",2.44071317292712,2.14691047014813,0.902252725147261,0.30127593,"regulation of steroid metabolic process"));

stuff <- data.frame(revigo.data);
names(stuff) <- revigo.names;

stuff$value <- as.numeric( as.character(stuff$value) );
stuff$frequency <- as.numeric( as.character(stuff$frequency) );
stuff$uniqueness <- as.numeric( as.character(stuff$uniqueness) );
stuff$dispensability <- as.numeric( as.character(stuff$dispensability) );

# by default, outputs to a PDF file
pdf( file="revigo_treemap.pdf", width=16, height=9 ) # width and height are in inches

# check the tmPlot command documentation for all possible parameters - there are a lot more
treemap(
  stuff,
  index = c("representative","description"),
  vSize = "value",
  type = "categorical",
  vColor = "representative",
  title = "Revigo TreeMap",
  inflate.labels = FALSE,      # set this to TRUE for space-filling group labels - good for posters
  lowerbound.cex.labels = 0,   # try to draw as many labels as possible (still, some small squares may not get a label)
  bg.labels = "#CCCCCCAA",   # define background color of group labels
								 # "#CCCCCC00" is fully transparent, "#CCCCCCAA" is semi-transparent grey, NA is opaque
  position.legend = "none"
)

dev.off()

