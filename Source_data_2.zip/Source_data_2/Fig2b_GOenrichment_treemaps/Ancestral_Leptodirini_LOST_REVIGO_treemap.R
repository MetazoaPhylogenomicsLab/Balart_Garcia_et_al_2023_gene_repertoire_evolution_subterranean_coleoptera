# A treemap R script produced by the Revigo server at http://revigo.irb.hr/
# If you found Revigo useful in your work, please cite the following reference:
# Supek F et al. "REVIGO summarizes and visualizes long lists of Gene Ontology
# terms" PLoS ONE 2011. doi:10.1371/journal.pone.0021800

# author: Anton Kratz <anton.kratz@gmail.com>, RIKEN Omics Science Center, Functional Genomics Technology Team, Japan
# created: Fri, Nov 02, 2012  7:25:52 PM
# last change: Fri, Nov 09, 2012  3:20:01 PM

# -----------------------------------------------------------------------------
# If you don't have the treemap package installed, uncomment the following line:
# install.packages( "treemap" );
library(treemap) 								# treemap package by Martijn Tennekes

# Set the working directory if necessary
# setwd("C:/Users/username/workingdir");

# --------------------------------------------------------------------------
# Here is your data from Revigo. Scroll down for plot configuration options.

revigo.names <- c("term_ID","description","frequency","value","uniqueness","dispensability","representative");
revigo.data <- rbind(c("GO:0007610","behavior",4.66505106456638,2.87289520163519,0.870118885536989,0,"behavior"),
c("GO:0007626","locomotory behavior",1.48866193526052,2.4089353929735,0.889317901964202,0.23836618,"behavior"),
c("GO:0003008","system process",5.920027696036,2.24488773360493,0.865272002598694,0.29421502,"behavior"),
c("GO:0008104","protein localization",6.42201834862385,2.24872089601666,1,0,"protein localization"),
c("GO:0023052","signaling",12.3333910334083,2.6252516539899,1,0,"signaling"),
c("GO:0032501","multicellular organismal process",29.3318331313831,3.62342304294349,1,0,"multicellular organismal process"),
c("GO:0032502","developmental process",23.6887657953955,3.48945498979339,1,0,"developmental process"),
c("GO:0032989","cellular component morphogenesis",4.60446598580578,5.44733178388781,0.577107059369187,0,"cellular component morphogenesis"),
c("GO:0031122","cytoplasmic microtubule organization",0.276960360048468,2.48280410205003,0.883079159212102,0.24574893,"cellular component morphogenesis"),
c("GO:0060322","head development",1.19439155270902,2.25414480482627,0.758634752289053,0.30880028,"cellular component morphogenesis"),
c("GO:0097435","supramolecular fiber organization",1.80024234031504,3.36451625318509,0.87811813659555,0.3105788,"cellular component morphogenesis"),
c("GO:0070925","organelle assembly",3.56586463562403,2.01010543628123,0.856749625760614,0.34368533,"cellular component morphogenesis"),
c("GO:0007423","sensory organ development",3.9034100744331,2.26680273489343,0.707605526962922,0.36664852,"cellular component morphogenesis"),
c("GO:0030030","cell projection organization",5.60844729098148,5.44733178388781,0.857624283870006,0.36980428,"cellular component morphogenesis"),
c("GO:0002165","instar larval or pupal development",4.71698113207547,2.47108329972235,0.665654282056858,0.37796811,"cellular component morphogenesis"),
c("GO:0040011","locomotion",5.63441232473602,4.76700388960785,1,0,"locomotion"),
c("GO:0042330","taxis",2.87346373550286,2.68402965454308,0.920745841052029,0,"taxis"),
c("GO:0007186","G protein-coupled receptor signaling pathway",1.91275748658473,2.24488773360493,0.830517794563627,0.29347033,"taxis"),
c("GO:0009605","response to external stimulus",8.25688073394496,2.96657624451305,0.937167181221576,0.36448565,"taxis"),
c("GO:0050896","response to stimulus",23.6368357278864,3.29328221766324,1,0,"response to stimulus"),
c("GO:0046716","muscle cell cellular homeostasis",0.285615371299983,4.76700388960785,0.916894605147091,0.02816595,"muscle cell cellular homeostasis"),
c("GO:0051130","positive regulation of cellular component organization",2.33685303790895,3.23957751657679,0.833562068161523,0.10578865,"muscle cell cellular homeostasis"),
c("GO:0010769","regulation of cell morphogenesis involved in differentiation",0.138480180024234,2.94692155651658,0.863820557356479,0.11875501,"muscle cell cellular homeostasis"),
c("GO:0051282","regulation of sequestering of calcium ion",0.069240090012117,2.47108329972235,0.917878177134552,0.12425711,"muscle cell cellular homeostasis"),
c("GO:0051336","regulation of hydrolase activity",2.45802319543015,2.52432881167557,0.917411076042167,0.13630341,"muscle cell cellular homeostasis"),
c("GO:0051239","regulation of multicellular organismal process",5.02856153713,3.48945498979339,0.892276300353514,0.18198683,"muscle cell cellular homeostasis"),
c("GO:0044087","regulation of cellular component biogenesis",2.64843344296348,2.88272870434424,0.895626705267965,0.18555074,"muscle cell cellular homeostasis"),
c("GO:0050789","regulation of biological process",37.4675437078068,2.96657624451305,0.869696754427846,0.2560899,"muscle cell cellular homeostasis"),
c("GO:0051128","regulation of cellular component organization",6.06716288731175,2.92081875395238,0.882594797126218,0.26879683,"muscle cell cellular homeostasis"),
c("GO:0010646","regulation of cell communication",8.20495066643587,2.41907502432438,0.8769821383561,0.29209736,"muscle cell cellular homeostasis"),
c("GO:0023051","regulation of signaling",8.20495066643587,2.68402965454308,0.883847910209102,0.29209736,"muscle cell cellular homeostasis"),
c("GO:0048518","positive regulation of biological process",15.7780855115112,2.70774392864352,0.870261355750207,0.35962969,"muscle cell cellular homeostasis"),
c("GO:1903078","positive regulation of protein localization to plasma membrane",0.069240090012117,2.0204516252959,0.895008546647587,0.39668813,"muscle cell cellular homeostasis"),
c("GO:0051240","positive regulation of multicellular organismal process",1.70503721654838,2.68402965454308,0.852940469848428,0.39734505,"muscle cell cellular homeostasis"),
c("GO:0030029","actin filament-based process",2.38878310541804,2.6252516539899,0.97301969508367,0.03694705,"actin filament-based process"),
c("GO:0007017","microtubule-based process",4.10247533321793,2.6252516539899,0.970746868499422,0.04013297,"microtubule-based process"),
c("GO:0006928","movement of cell or subcellular component",6.04985286480872,4.07468790850035,0.968865048727134,0.04278275,"movement of cell or subcellular component"),
c("GO:0007154","cell communication",12.9132767872598,2.51286162452281,0.964414546735848,0.05187556,"cell communication"));

stuff <- data.frame(revigo.data);
names(stuff) <- revigo.names;

stuff$value <- as.numeric( as.character(stuff$value) );
stuff$frequency <- as.numeric( as.character(stuff$frequency) );
stuff$uniqueness <- as.numeric( as.character(stuff$uniqueness) );
stuff$dispensability <- as.numeric( as.character(stuff$dispensability) );

# by default, outputs to a PDF file
pdf( file="revigo_treemap.pdf", width=16, height=9 ) # width and height are in inches

# check the tmPlot command documentation for all possible parameters - there are a lot more
treemap(
  stuff,
  index = c("representative","description"),
  vSize = "value",
  type = "categorical",
  vColor = "representative",
  title = "Revigo TreeMap",
  inflate.labels = FALSE,      # set this to TRUE for space-filling group labels - good for posters
  lowerbound.cex.labels = 0,   # try to draw as many labels as possible (still, some small squares may not get a label)
  bg.labels = "#CCCCCCAA",   # define background color of group labels
								 # "#CCCCCC00" is fully transparent, "#CCCCCCAA" is semi-transparent grey, NA is opaque
  position.legend = "none"
)

dev.off()

