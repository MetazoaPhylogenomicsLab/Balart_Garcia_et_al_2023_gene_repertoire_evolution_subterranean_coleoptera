# A treemap R script produced by the Revigo server at http://revigo.irb.hr/
# If you found Revigo useful in your work, please cite the following reference:
# Supek F et al. "REVIGO summarizes and visualizes long lists of Gene Ontology
# terms" PLoS ONE 2011. doi:10.1371/journal.pone.0021800

# author: Anton Kratz <anton.kratz@gmail.com>, RIKEN Omics Science Center, Functional Genomics Technology Team, Japan
# created: Fri, Nov 02, 2012  7:25:52 PM
# last change: Fri, Nov 09, 2012  3:20:01 PM

# -----------------------------------------------------------------------------
# If you don't have the treemap package installed, uncomment the following line:
# install.packages( "treemap" );
library(treemap) 								# treemap package by Martijn Tennekes

# Set the working directory if necessary
# setwd("C:/Users/username/workingdir");

# --------------------------------------------------------------------------
# Here is your data from Revigo. Scroll down for plot configuration options.

revigo.names <- c("term_ID","description","frequency","value","uniqueness","dispensability","representative");
revigo.data <- rbind(c("GO:0000003","reproduction",12.5757313484508,3.16877030613294,1,0,"reproduction"),
c("GO:0006935","chemotaxis",2.37147308291501,3.37882371822496,0.896487169713184,0,"chemotaxis"),
c("GO:0009719","response to endogenous stimulus",1.50597195776355,2.17069622716898,0.953369005903328,0.27753068,"chemotaxis"),
c("GO:0009607","response to biotic stimulus",3.548554613121,2.05060999335509,0.947926321552854,0.31112705,"chemotaxis"),
c("GO:0006952","defense response",3.3754543880907,2.012780770092,0.948275359827675,0.32745368,"chemotaxis"),
c("GO:0009605","response to external stimulus",8.25688073394496,7.12842706445412,0.941364957807228,0.37767231,"chemotaxis"),
c("GO:0007610","behavior",4.66505106456638,3.80134291304558,0.850637546682125,0,"behavior"),
c("GO:0003008","system process",5.920027696036,3.84466396253494,0.845021027571529,0.29421502,"behavior"),
c("GO:0050877","nervous system process",5.30552189717847,2.61083391563547,0.847654956481895,0.30078259,"behavior"),
c("GO:0022603","regulation of anatomical structure morphogenesis",1.60983209278172,5.13906337929991,0.859997341001601,0,"regulation of anatomical structure morphogenesis"),
c("GO:0010975","regulation of neuron projection development",0.865501125151463,4.35457773065091,0.87209988238683,0.13828174,"regulation of anatomical structure morphogenesis"),
c("GO:0040012","regulation of locomotion",1.04725636143327,2.52578373592374,0.917181381208994,0.14131572,"regulation of anatomical structure morphogenesis"),
c("GO:0051270","regulation of cellular component movement",1.04725636143327,2.84466396253494,0.898536573486757,0.14725808,"regulation of anatomical structure morphogenesis"),
c("GO:0032879","regulation of localization",4.82084126709365,3.26680273489343,0.898077147752677,0.1714441,"regulation of anatomical structure morphogenesis"),
c("GO:2000112","regulation of cellular macromolecule biosynthetic process",2.08585771161503,2.17069622716898,0.87575864359307,0.17787866,"regulation of anatomical structure morphogenesis"),
c("GO:0065008","regulation of biological quality",11.4073048294963,2.80687540164554,0.901083360218378,0.19548209,"regulation of anatomical structure morphogenesis"),
c("GO:0023056","positive regulation of signaling",3.99861519819976,2.54515513999149,0.881682918022718,0.19639562,"regulation of anatomical structure morphogenesis"),
c("GO:0050793","regulation of developmental process",5.82482257226934,5.46344155742847,0.895074793981036,0.2089704,"regulation of anatomical structure morphogenesis"),
c("GO:0051239","regulation of multicellular organismal process",5.02856153713,5.08724669632868,0.897422626523341,0.2104817,"regulation of anatomical structure morphogenesis"),
c("GO:0051128","regulation of cellular component organization",6.06716288731175,4.42021640338319,0.887270989499327,0.21748209,"regulation of anatomical structure morphogenesis"),
c("GO:0023051","regulation of signaling",8.20495066643587,3.42829116819131,0.889163752805124,0.23153365,"regulation of anatomical structure morphogenesis"),
c("GO:0010646","regulation of cell communication",8.20495066643587,3.36957212497498,0.881709515565454,0.25850331,"regulation of anatomical structure morphogenesis"),
c("GO:0050789","regulation of biological process",37.4675437078068,2.16115090926274,0.875636737460811,0.32262786,"regulation of anatomical structure morphogenesis"),
c("GO:0023052","signaling",12.3333910334083,2.05700040663396,1,0,"signaling"),
c("GO:0032501","multicellular organismal process",29.3318331313831,8.27736607746619,1,0,"multicellular organismal process"),
c("GO:0032502","developmental process",23.6887657953955,8.27736607746619,1,0,"developmental process"),
c("GO:0032989","cellular component morphogenesis",4.60446598580578,8.25884840114822,0.600085121402219,0,"cellular component morphogenesis"),
c("GO:0043062","extracellular structure organization",0.701055911372685,2.26201267366657,0.918767117175117,0.27414114,"cellular component morphogenesis"),
c("GO:0060322","head development",1.19439155270902,2.67571754470231,0.760333154394918,0.30880028,"cellular component morphogenesis"),
c("GO:0097435","supramolecular fiber organization",1.80024234031504,4.80134291304558,0.908907356857595,0.3105788,"cellular component morphogenesis"),
c("GO:0030036","actin cytoskeleton organization",2.24164791414229,3.01367622294923,0.881396805108407,0.32048366,"cellular component morphogenesis"),
c("GO:0061061","muscle structure development",1.7742773065605,2.51427857351842,0.747991394727544,0.32598889,"cellular component morphogenesis"),
c("GO:0048569","post-embryonic animal organ development",3.9639951531937,3.58838029403677,0.695709261063857,0.36754402,"cellular component morphogenesis"),
c("GO:0030030","cell projection organization",5.60844729098148,4.57186520597121,0.893382919666768,0.36980428,"cellular component morphogenesis"),
c("GO:0002165","instar larval or pupal development",4.71698113207547,5.18775530319963,0.642251691411018,0.37796811,"cellular component morphogenesis"),
c("GO:0040011","locomotion",5.63441232473602,3.74472749489669,1,0,"locomotion"),
c("GO:0044419","biological process involved in interspecies interaction between organisms",3.77358490566038,2.5543957967264,1,0,"biological process involved in interspecies interaction between organisms"),
c("GO:0044703","multi-organism reproductive process",0.22503029253938,3.73992861201493,0.96764405249788,0,"multi-organism reproductive process"),
c("GO:0050896","response to stimulus",23.6368357278864,2.28650945690606,1,0,"response to stimulus"),
c("GO:0065007","biological regulation",41.7604292885581,2.79317412396815,1,0,"biological regulation"),
c("GO:0030029","actin filament-based process",2.38878310541804,3.84163750790475,0.981774838492543,0.03694705,"actin filament-based process"),
c("GO:0006928","movement of cell or subcellular component",6.04985286480872,3.16115090926274,0.978930844747539,0.04278275,"movement of cell or subcellular component"),
c("GO:0007154","cell communication",12.9132767872598,2.61083391563547,0.975865256471211,0.05187556,"cell communication"),
c("GO:0071840","cellular component organization or biogenesis",25.1081876406439,2.49349496759513,0.972388671701616,0.0734065,"cellular component organization or biogenesis"));

stuff <- data.frame(revigo.data);
names(stuff) <- revigo.names;

stuff$value <- as.numeric( as.character(stuff$value) );
stuff$frequency <- as.numeric( as.character(stuff$frequency) );
stuff$uniqueness <- as.numeric( as.character(stuff$uniqueness) );
stuff$dispensability <- as.numeric( as.character(stuff$dispensability) );

# by default, outputs to a PDF file
pdf( file="revigo_treemap.pdf", width=16, height=9 ) # width and height are in inches

# check the tmPlot command documentation for all possible parameters - there are a lot more
treemap(
  stuff,
  index = c("representative","description"),
  vSize = "value",
  type = "categorical",
  vColor = "representative",
  title = "Revigo TreeMap",
  inflate.labels = FALSE,      # set this to TRUE for space-filling group labels - good for posters
  lowerbound.cex.labels = 0,   # try to draw as many labels as possible (still, some small squares may not get a label)
  bg.labels = "#CCCCCCAA",   # define background color of group labels
								 # "#CCCCCC00" is fully transparent, "#CCCCCCAA" is semi-transparent grey, NA is opaque
  position.legend = "none"
)

dev.off()

