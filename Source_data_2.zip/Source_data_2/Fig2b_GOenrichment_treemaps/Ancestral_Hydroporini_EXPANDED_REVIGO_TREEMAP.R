# A treemap R script produced by the Revigo server at http://revigo.irb.hr/
# If you found Revigo useful in your work, please cite the following reference:
# Supek F et al. "REVIGO summarizes and visualizes long lists of Gene Ontology
# terms" PLoS ONE 2011. doi:10.1371/journal.pone.0021800

# author: Anton Kratz <anton.kratz@gmail.com>, RIKEN Omics Science Center, Functional Genomics Technology Team, Japan
# created: Fri, Nov 02, 2012  7:25:52 PM
# last change: Fri, Nov 09, 2012  3:20:01 PM

# -----------------------------------------------------------------------------
# If you don't have the treemap package installed, uncomment the following line:
# install.packages( "treemap" );
library(treemap) 								# treemap package by Martijn Tennekes

# Set the working directory if necessary
# setwd("C:/Users/username/workingdir");

# --------------------------------------------------------------------------
# Here is your data from Revigo. Scroll down for plot configuration options.

revigo.names <- c("term_ID","description","frequency","value","uniqueness","dispensability","representative");
revigo.data <- rbind(c("GO:0000003","reproduction",12.5757313484508,4.54515513999149,1,0,"reproduction"),
c("GO:0023052","signaling",12.3333910334083,4.04527520902094,1,0,"signaling"),
c("GO:0023056","positive regulation of signaling",3.99861519819976,5.14996674231023,0.874843435911,0,"positive regulation of signaling"),
c("GO:0050678","regulation of epithelial cell proliferation",0.0173100225030293,2.08092190762393,0.946693879090841,0.10333898,"positive regulation of signaling"),
c("GO:0030100","regulation of endocytosis",0.536610697593907,2.69680394257951,0.913590235656769,0.14535035,"positive regulation of signaling"),
c("GO:0042592","homeostatic process",4.04189025445733,3.45469288353418,0.904060836696662,0.15824066,"positive regulation of signaling"),
c("GO:2000026","regulation of multicellular organismal development",2.39743811666955,3.11520463605102,0.857086815183276,0.17665578,"positive regulation of signaling"),
c("GO:0065008","regulation of biological quality",11.4073048294963,4.67778070526608,0.907670912284825,0.18907782,"positive regulation of signaling"),
c("GO:0032879","regulation of localization",4.82084126709365,2.44733178388781,0.906617932083523,0.19639562,"positive regulation of signaling"),
c("GO:0051239","regulation of multicellular organismal process",5.02856153713,4.98296666070122,0.906016611537549,0.20386974,"positive regulation of signaling"),
c("GO:0023051","regulation of signaling",8.20495066643587,4.23136189875239,0.89841280278549,0.22361591,"positive regulation of signaling"),
c("GO:0050793","regulation of developmental process",5.82482257226934,3.64975198166584,0.903858151224293,0.2297674,"positive regulation of signaling"),
c("GO:0010646","regulation of cell communication",8.20495066643587,4.13430394008393,0.893509060243295,0.24550876,"positive regulation of signaling"),
c("GO:0006357","regulation of transcription by RNA polymerase II",7.95395534014194,2.08460016478773,0.880427644557269,0.27241389,"positive regulation of signaling"),
c("GO:0050794","regulation of cellular process",34.897005366107,2.35163998901907,0.86674342809609,0.34553518,"positive regulation of signaling"),
c("GO:0048583","regulation of response to stimulus",8.81080145404189,2.24260397120698,0.897200931635025,0.3526048,"positive regulation of signaling"),
c("GO:0032501","multicellular organismal process",29.3318331313831,6.83564714421556,1,0,"multicellular organismal process"),
c("GO:0032502","developmental process",23.6887657953955,5.03715731879876,1,0,"developmental process"),
c("GO:0040011","locomotion",5.63441232473602,4.21183162885883,1,0,"locomotion"),
c("GO:0042330","taxis",2.87346373550286,5.27002571430044,0.929943163303645,0,"taxis"),
c("GO:0070493","thrombin-activated receptor signaling pathway",0.102325009338302,2.0204516252959,0.904892608381965,0.21111558,"taxis"),
c("GO:0009628","response to abiotic stimulus",3.56586463562403,2.91721462968355,0.96545514043281,0.32002562,"taxis"),
c("GO:0009605","response to external stimulus",8.25688073394496,6.09366495819491,0.961196192302446,0.37798766,"taxis"),
c("GO:0048667","cell morphogenesis involved in neuron differentiation",3.41007443309676,5.40230481407449,0.523688764735107,0,"cell morphogenesis involved in neuron differentiation"),
c("GO:0007611","learning or memory",1.37614678899083,3.58838029403677,0.814640507231712,0.22617608,"cell morphogenesis involved in neuron differentiation"),
c("GO:0007610","behavior",4.66505106456638,3.64975198166584,0.810202657748551,0.26902826,"cell morphogenesis involved in neuron differentiation"),
c("GO:0001568","blood vessel development",0.00865501125151463,2.41341269532824,0.77807241344054,0.29235713,"cell morphogenesis involved in neuron differentiation"),
c("GO:0003008","system process",5.920027696036,4.73518217699046,0.803502189840984,0.29421502,"cell morphogenesis involved in neuron differentiation"),
c("GO:0060322","head development",1.19439155270902,2.80687540164554,0.740470308130687,0.29692086,"cell morphogenesis involved in neuron differentiation"),
c("GO:0048569","post-embryonic animal organ development",3.9639951531937,4.04527520902094,0.67425959612247,0.35083726,"cell morphogenesis involved in neuron differentiation"),
c("GO:0048736","appendage development",2.85615371299983,4.42829116819131,0.648630152977392,0.39355164,"cell morphogenesis involved in neuron differentiation"),
c("GO:0051179","localization",21.1788125324563,2.40120949323688,1,0,"localization"),
c("GO:0007163","establishment or maintenance of cell polarity",1.69638220529687,2.42829116819131,0.983838676756491,0.03376247,"establishment or maintenance of cell polarity"),
c("GO:1903046","meiotic cell cycle process",1.70503721654838,4.47755576649368,0.869693982750456,0.03378553,"meiotic cell cycle process"),
c("GO:0044703","multi-organism reproductive process",0.22503029253938,3.29670862188134,0.924984852676856,0.39513865,"meiotic cell cycle process"),
c("GO:0051674","localization of cell",2.97732387052103,2.3269790928711,0.974487006369287,0.03651794,"localization of cell"),
c("GO:0030030","cell projection organization",5.60844729098148,5.34969247686806,0.926887845432604,0.04021241,"cell projection organization"),
c("GO:0006928","movement of cell or subcellular component",6.04985286480872,4.54211810326601,0.980539000625208,0.04426687,"movement of cell or subcellular component"),
c("GO:0007154","cell communication",12.9132767872598,3.62708799702989,0.977861976230137,0.05187556,"cell communication"));

stuff <- data.frame(revigo.data);
names(stuff) <- revigo.names;

stuff$value <- as.numeric( as.character(stuff$value) );
stuff$frequency <- as.numeric( as.character(stuff$frequency) );
stuff$uniqueness <- as.numeric( as.character(stuff$uniqueness) );
stuff$dispensability <- as.numeric( as.character(stuff$dispensability) );

# by default, outputs to a PDF file
pdf( file="revigo_treemap.pdf", width=16, height=9 ) # width and height are in inches

# check the tmPlot command documentation for all possible parameters - there are a lot more
treemap(
  stuff,
  index = c("representative","description"),
  vSize = "value",
  type = "categorical",
  vColor = "representative",
  title = "Revigo TreeMap",
  inflate.labels = FALSE,      # set this to TRUE for space-filling group labels - good for posters
  lowerbound.cex.labels = 0,   # try to draw as many labels as possible (still, some small squares may not get a label)
  bg.labels = "#CCCCCCAA",   # define background color of group labels
								 # "#CCCCCC00" is fully transparent, "#CCCCCCAA" is semi-transparent grey, NA is opaque
  position.legend = "none"
)

dev.off()

