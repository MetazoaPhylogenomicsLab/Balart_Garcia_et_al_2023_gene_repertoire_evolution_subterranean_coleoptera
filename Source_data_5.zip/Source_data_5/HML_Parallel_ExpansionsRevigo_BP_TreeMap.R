# A treemap R script produced by the Revigo server at http://revigo.irb.hr/
# If you found Revigo useful in your work, please cite the following reference:
# Supek F et al. "REVIGO summarizes and visualizes long lists of Gene Ontology
# terms" PLoS ONE 2011. doi:10.1371/journal.pone.0021800

# author: Anton Kratz <anton.kratz@gmail.com>, RIKEN Omics Science Center, Functional Genomics Technology Team, Japan
# created: Fri, Nov 02, 2012  7:25:52 PM
# last change: Fri, Nov 09, 2012  3:20:01 PM

# -----------------------------------------------------------------------------
# If you don't have the treemap package installed, uncomment the following line:
# install.packages( "treemap" );
library(treemap) 								# treemap package by Martijn Tennekes

# Set the working directory if necessary
# setwd("C:/Users/username/workingdir");

# --------------------------------------------------------------------------
# Here is your data from Revigo. Scroll down for plot configuration options.

revigo.names <- c("term_ID","description","frequency","value","uniqueness","dispensability","representative");
revigo.data <- rbind(c("GO:0001775","cell activation",0.111923810782242,2.02319166266193,0.996371911588834,0.00992578,"cell activation"),
c("GO:0002376","immune system process",0.575433057680739,3.62160209905186,1,0,"immune system process"),
c("GO:0006793","phosphorus metabolic process",13.2524156349561,2.17522353752445,0.98973266198015,0.08221683,"phosphorus metabolic process"),
c("GO:0006928","movement of cell or subcellular component",0.954688672058941,4.20481541031758,0.995684510110472,0,"movement of cell or subcellular component"),
c("GO:0007154","cell communication",8.51956166642549,4.74714696902011,0.994612440755954,0.01597011,"cell communication"),
c("GO:0007155","cell adhesion",0.688087491365405,3.29670862188134,0.995807047881327,0.01179755,"cell adhesion"),
c("GO:0007163","establishment or maintenance of cell polarity",0.0727194861317905,2.05354773498693,0.996483300933386,0.00956544,"establishment or maintenance of cell polarity"),
c("GO:0007618","mating",0.000277013422720025,2.44611697335613,0.98925294365245,0,"mating"),
c("GO:0008037","cell recognition",0.0930245700171683,2.14935376481693,0.996420585644504,0.00976795,"cell recognition"),
c("GO:0008219","cell death",0.317298099719084,2.0301183562535,0.996069219645688,0.01091985,"cell death"),
c("GO:0009187","cyclic nucleotide metabolic process",0.164327825025303,3.57186520597121,0.981528403748687,0.01027036,"cyclic nucleotide metabolic process"),
c("GO:0006468","protein phosphorylation",4.14863958534969,2.42829116819131,0.981476898072554,0.37109553,"cyclic nucleotide metabolic process"),
c("GO:0009190","cyclic nucleotide biosynthetic process",0.148022122430445,2.73518217699046,0.97788412455329,0.48076691,"cyclic nucleotide metabolic process"),
c("GO:0016444","somatic cell DNA recombination",0.00890944420823279,2.1438755557577,0.985451553524831,0.17091209,"cyclic nucleotide metabolic process"),
c("GO:0018130","heterocycle biosynthetic process",8.64654808206813,2.44129142946683,0.98205419189051,0.49129626,"cyclic nucleotide metabolic process"),
c("GO:0019438","aromatic compound biosynthetic process",8.34145242361987,2.61083391563547,0.982137992398934,0.46328957,"cyclic nucleotide metabolic process"),
c("GO:0034654","nucleobase-containing compound biosynthetic process",6.26212388199547,2.80687540164554,0.979871121036155,0.49034766,"cyclic nucleotide metabolic process"),
c("GO:1901362","organic cyclic compound biosynthetic process",9.22162794763491,2.86966623150499,0.987570872296132,0.26161664,"cyclic nucleotide metabolic process"),
c("GO:0023052","signaling",8.00630080880648,5.19997064075587,1,0,"signaling"),
c("GO:0030029","actin filament-based process",0.43265341427527,2.80966830182971,0.995968489475991,0.0112553,"actin filament-based process"),
c("GO:0030030","cell projection organization",0.699181878945342,4.11918640771921,0.970186230994228,0.01181718,"cell projection organization"),
c("GO:0007010","cytoskeleton organization",0.957784297057837,2.86012091359876,0.968701503326445,0.49350722,"cell projection organization"),
c("GO:0043062","extracellular structure organization",0.090656105252912,2.04963514562388,0.974366780092747,0.39629938,"cell projection organization"),
c("GO:0120036","plasma membrane bounded cell projection organization",0.403480438195068,4.18842499412941,0.955829651218532,0.45278156,"cell projection organization"),
c("GO:0032501","multicellular organismal process",2.55658111695759,6.02045162529591,1,0,"multicellular organismal process"),
c("GO:0032502","developmental process",2.47966141480381,4.11918640771921,1,0,"developmental process"),
c("GO:0040007","growth",0.106238110280913,2.04769199033787,1,0,"growth"),
c("GO:0040011","locomotion",0.944913560904708,5.42829116819131,1,0,"locomotion"),
c("GO:0048731","system development",1.25694840559211,6.59516628338006,0.587387914291949,0,"system development"),
c("GO:0007473","wing disc proximal/distal pattern formation",4.84773489760043E-05,2.0301183562535,0.714445620313968,0.44394002,"system development"),
c("GO:0021531","spinal cord radial glial cell differentiation",1.38506711360012E-05,2.80134291304558,0.735046040266949,0.41636521,"system development"),
c("GO:0032633","interleukin-4 production",0.000358633449057175,2.02273378757271,0.805990420912411,0.42244058,"system development"),
c("GO:0035165","embryonic crystal cell differentiation",9.0029362384008E-05,4.45469288353418,0.70779948524376,0.45895974,"system development"),
c("GO:0042113","B cell activation",0.0265344232287944,2.76700388960785,0.956224206331704,0.46293085,"system development"),
c("GO:0042675","compound eye cone cell differentiation",0.000266625419368024,3.17263072694617,0.695499419006211,0.48791142,"system development"),
c("GO:0060843","venous endothelial cell differentiation",0.000238924077096021,2.80134291304558,0.697988622658343,0.48482134,"system development"),
c("GO:1902263","apoptotic process involved in embryonic digit morphogenesis",0.000360117449536032,2.80134291304558,0.709947427924368,0.49658397,"system development"),
c("GO:1904238","pericyte cell differentiation",0.00152011115717613,2.55284196865778,0.75734440511303,0.46609285,"system development"),
c("GO:0050896","response to stimulus",14.3743892503279,4.75696195131371,1,0,"response to stimulus"),
c("GO:0051239","regulation of multicellular organismal process",0.541408884035152,5.42829116819131,0.834421567143455,0,"regulation of multicellular organismal process"),
c("GO:0002213","defense response to insect",0.00056787751657605,2.25026368443094,0.9663024188585,0.4485327,"regulation of multicellular organismal process"),
c("GO:0002682","regulation of immune system process",0.310899089654252,2.76955107862173,0.841475493587698,0.2078424,"regulation of multicellular organismal process"),
c("GO:0006357","regulation of transcription by RNA polymerase II",1.85424128499324,2.08460016478773,0.782987688292994,0.45959378,"regulation of multicellular organismal process"),
c("GO:0006952","defense response",1.03404955500044,2.17069622716898,0.954633424809705,0.37501231,"regulation of multicellular organismal process"),
c("GO:0007186","G protein-coupled receptor signaling pathway",1.37578023860343,4.62342304294349,0.767583765208233,0.2711511,"regulation of multicellular organismal process"),
c("GO:0007264","small GTPase mediated signal transduction",0.307332541836731,3.03105031901866,0.794200121876173,0.46596783,"regulation of multicellular organismal process"),
c("GO:0007265","Ras protein signal transduction",0.0687893581969501,2.06348625752111,0.815361493047027,0.48207157,"regulation of multicellular organismal process"),
c("GO:0007267","cell-cell signaling",0.429114567800022,2.1605219526258,0.985918384639859,0.47708808,"regulation of multicellular organismal process"),
c("GO:0009582","detection of abiotic stimulus",0.0696792638174382,2.46218090492673,0.963306300397386,0.28747281,"regulation of multicellular organismal process"),
c("GO:0009605","response to external stimulus",1.94984900517728,4.11918640771921,0.952838167205841,0.40393635,"regulation of multicellular organismal process"),
c("GO:0009607","response to biotic stimulus",0.85178511085402,2.14813039927023,0.956671928806992,0.36697891,"regulation of multicellular organismal process"),
c("GO:0009628","response to abiotic stimulus",0.571118573621875,3.45717457304082,0.958307534037189,0.35145803,"regulation of multicellular organismal process"),
c("GO:0009719","response to endogenous stimulus",0.644364385256833,2.88605664769316,0.95782702774505,0.35600314,"regulation of multicellular organismal process"),
c("GO:0010646","regulation of cell communication",1.06082290230633,3.42250820016277,0.815987331576345,0.28129295,"regulation of multicellular organismal process"),
c("GO:0010810","regulation of cell-substrate adhesion",0.0322824517502349,3.07883394936226,0.850497604212854,0.17233315,"regulation of multicellular organismal process"),
c("GO:0010941","regulation of cell death",0.369851008676857,2.61083391563547,0.831061258494506,0.22537985,"regulation of multicellular organismal process"),
c("GO:0010975","regulation of neuron projection development",0.0582524601302372,3.61261017366127,0.82916589884098,0.18036367,"regulation of multicellular organismal process"),
c("GO:0019220","regulation of phosphate metabolic process",0.441126562342719,4.11918640771921,0.785562680565899,0.21467514,"regulation of multicellular organismal process"),
c("GO:0019222","regulation of metabolic process",13.6375716352383,2.24488773360493,0.775006020325809,0.38344105,"regulation of multicellular organismal process"),
c("GO:0022603","regulation of anatomical structure morphogenesis",0.887100859583039,4.48678239993206,0.714418325544051,0.25676619,"regulation of multicellular organismal process"),
c("GO:0023051","regulation of signaling",1.07005437461848,3.5543957967264,0.824797469417143,0.26272176,"regulation of multicellular organismal process"),
c("GO:0023056","positive regulation of signaling",0.327544133691941,4.20481541031758,0.739916161741173,0.20883324,"regulation of multicellular organismal process"),
c("GO:0030155","regulation of cell adhesion",0.117796495343906,2.97469413473523,0.844759593388295,0.19098058,"regulation of multicellular organismal process"),
c("GO:0031399","regulation of protein modification process",0.447819899169192,2.86966623150499,0.800569687845855,0.34815347,"regulation of multicellular organismal process"),
c("GO:0040008","regulation of growth",0.167762791467031,2.47495519296315,0.84861836976249,0.1967975,"regulation of multicellular organismal process"),
c("GO:0040012","regulation of locomotion",0.179099565791848,2.86966623150499,0.847893188325009,0.19791228,"regulation of multicellular organismal process"),
c("GO:0042221","response to chemical",3.60288159057783,3.32239304727951,0.949532360072394,0.45749406,"regulation of multicellular organismal process"),
c("GO:0042330","taxis",0.588248391149324,4.47108329972234,0.931961583190111,0.3525604,"regulation of multicellular organismal process"),
c("GO:0042592","homeostatic process",0.8601647668913,5.42829116819131,0.816474010102313,0.21292796,"regulation of multicellular organismal process"),
c("GO:0042981","regulation of apoptotic process",0.335068510786574,2.79860287567955,0.819215416254229,0.22337847,"regulation of multicellular organismal process"),
c("GO:0045892","negative regulation of transcription, DNA-templated",0.649932355053506,2.86966623150499,0.722237224019132,0.34586029,"regulation of multicellular organismal process"),
c("GO:0045967","negative regulation of growth rate",0.00022853607374402,2.55284196865778,0.838724527351763,0.39410646,"regulation of multicellular organismal process"),
c("GO:0048583","regulation of response to stimulus",1.34673191856346,2.46092390120722,0.821275858152489,0.27041437,"regulation of multicellular organismal process"),
c("GO:0050790","regulation of catalytic activity",2.07426265865641,2.55284196865778,0.813786347057111,0.28615082,"regulation of multicellular organismal process"),
c("GO:0050793","regulation of developmental process",1.26729139426292,3.51004152057517,0.822221389451928,0.26833716,"regulation of multicellular organismal process"),
c("GO:0051128","regulation of cellular component organization",0.899905805048272,2.89619627904404,0.818525116497398,0.27614938,"regulation of multicellular organismal process"),
c("GO:0051174","regulation of phosphorus metabolic process",0.441282382392999,4.11918640771921,0.811069438604798,0.33350337,"regulation of multicellular organismal process"),
c("GO:0051606","detection of stimulus",0.446583726770304,3.08777794346758,0.959253653815986,0.34254351,"regulation of multicellular organismal process"),
c("GO:0065008","regulation of biological quality",2.88222078336834,4.89619627904404,0.82014633417754,0.25581258,"regulation of multicellular organismal process"),
c("GO:0065009","regulation of molecular function",2.23354191405264,2.67985371388895,0.824395902019759,0.28903184,"regulation of multicellular organismal process"),
c("GO:0071495","cellular response to endogenous stimulus",0.534725935212031,3.09636748391576,0.954471183626764,0.34902658,"regulation of multicellular organismal process"),
c("GO:0090287","regulation of cellular response to growth factor stimulus",0.0655032864699338,3.32882715728492,0.809888441504522,0.18204972,"regulation of multicellular organismal process"),
c("GO:1901189","positive regulation of ephrin receptor signaling pathway",0.000138506711360012,2.44129142946683,0.816716196477927,0.46732521,"regulation of multicellular organismal process"),
c("GO:1901700","response to oxygen-containing compound",0.569328374377547,3.61798295742513,0.944091234796612,0.35134133,"regulation of multicellular organismal process"),
c("GO:1903530","regulation of secretion by cell",0.0984921224481047,4.24412514432751,0.802225577356417,0.18816532,"regulation of multicellular organismal process"),
c("GO:1903578","regulation of ATP metabolic process",0.010741195465969,2.30539480106643,0.860097775000049,0.23631142,"regulation of multicellular organismal process"),
c("GO:1903849","positive regulation of aorta morphogenesis",0.000252774748232022,2.67985371388895,0.779687504235401,0.48973973,"regulation of multicellular organismal process"),
c("GO:1905904","positive regulation of mesoderm formation",0.000315102768344028,2.7281583934635,0.780660220655538,0.49594569,"regulation of multicellular organismal process"),
c("GO:2000241","regulation of reproductive process",0.0726744714505985,2.12262865413023,0.857299642053027,0.18356938,"regulation of multicellular organismal process"),
c("GO:2000974","negative regulation of pro-B cell differentiation",0.000322028103912029,2.80134291304558,0.748371897149221,0.49656637,"regulation of multicellular organismal process"),
c("GO:0051674","localization of cell",0.506335522051013,2.86327943284359,0.98064905875004,0.01143342,"localization of cell"),
c("GO:0006811","ion transport",5.34306259876611,2.43770713554353,0.979287568406562,0.4355673,"localization of cell"),
c("GO:0009306","protein secretion",0.367797646680945,2.11013827874181,0.974282567483598,0.24842687,"localization of cell"),
c("GO:0098655","cation transmembrane transport",3.00828612938043,2.0762380391713,0.974998237508433,0.30782623,"localization of cell"),
c("GO:0065007","biological regulation",24.4994376108119,2.46344155742847,1,0,"biological regulation"),
c("GO:0098609","cell-cell adhesion",0.27344341223472,2.74714696902011,0.996115667195904,0.01076593,"cell-cell adhesion"));

stuff <- data.frame(revigo.data);
names(stuff) <- revigo.names;

stuff$value <- as.numeric( as.character(stuff$value) );
stuff$frequency <- as.numeric( as.character(stuff$frequency) );
stuff$uniqueness <- as.numeric( as.character(stuff$uniqueness) );
stuff$dispensability <- as.numeric( as.character(stuff$dispensability) );

# by default, outputs to a PDF file
pdf( file="revigo_treemap.pdf", width=16, height=9 ) # width and height are in inches

# check the tmPlot command documentation for all possible parameters - there are a lot more
treemap(
  stuff,
  index = c("representative","description"),
  vSize = "value",
  type = "categorical",
  vColor = "representative",
  inflate.labels = FALSE,      # set this to TRUE for space-filling group labels - good for posters
  lowerbound.cex.labels = 0,   # try to draw as many labels as possible (still, some small squares may not get a label)
  position.legend = "none"
)

dev.off()

