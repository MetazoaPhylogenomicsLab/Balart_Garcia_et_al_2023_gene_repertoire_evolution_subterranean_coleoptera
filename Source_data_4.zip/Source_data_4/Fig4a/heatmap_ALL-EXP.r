#APCluster heatmap:

##linexcsim<-as.matrix(linexcsim)
##heatmap(x=cluster_apc_linexcsim, y=linexcsim)


#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("ComplexHeatmap")

#install.packages("ComplexHeatmap")
#install.packages("dplyr")
#install.packages("dendextend")
#install.packages("RColorBrewer")
#install.packages("apcluster")
#install.packages("ggplot2")
#install.packages("circlize")
#install.packages("dendextend")

library(ComplexHeatmap)
library(dplyr)
library(dendextend)
library(RColorBrewer)
library(apcluster)
library(ggplot2)
library(circlize)
library(dendextend)

# SimMatrix
linexcsim_all <- read.table("Exp_ALL_SimMat_NMDS.txt", h=T) #original matrix
remark_exp_ogs <- read.table("remarkable_expanded_OGs_all.txt", h=F) # expansions consisting of more than 1 gene gain
linexcsim <- linexcsim_all[names(linexcsim_all) %in% remark_exp_ogs$V1]
linexcsim <- linexcsim[(row.names(linexcsim)) %in% (remark_exp_ogs$V1),] # reduced matrix just with remarkably expanded OGs(>2 gains)

# Compute MDS

xx <- cmdscale(as.matrix(as.dist(1 - linexcsim)), eig = TRUE, 
               k = 2) #METRIC MDS
mds <- data.frame(xx$points)
colnames(mds)[1:2] <-c("MDS.1","MDS.2")
head(mds)

# Compute clusters using APC
require(apcluster)
cluster_apc_linexcsim <- apcluster(as.matrix(linexcsim), details=T) #on similarity matrix

# Reduce columns of SimMat to exemplar OGs:
exemplars <- data.frame(labels(cluster_apc_linexcsim))
linexcsim <- linexcsim[names(linexcsim) %in% exemplars$labels.cluster_apc_linexcsim.]

# Formatting for plotting apc clusters in heatmap
anots <- read.table("Exp_ALL_scatterplot_table.txt", header = TRUE, sep = "\t", row.names = 1, dec = ".")
anots$MDS.1 <- NULL
anots$MDS.2 <- NULL
anots$NMDS.1 <- NULL
anots$NMDS.2 <- NULL
anots$apclusters_q0 <- NULL
anots$apclusters_q0_id <- NULL
anots$label_q0 <- NULL

anots <- anots[(row.names(anots)) %in% (remark_exp_ogs$V1),]

anots <- cbind.data.frame(anots, mds)
anots <- cbind.data.frame(anots, "Cluster_exemplar"=labels(cluster_apc_linexcsim))
head(anots)

#Heatmap

#RAW heatmap:
Heatmap(as.matrix(linexcsim), 
        name = "Functional similarity", #title of legend
        column_title = "Exclusively Expanded OGs", row_title = "Samples",
        row_names_gp = gpar(fontsize = 7) # Text size for row names
        )


#Legend - reduced functions: << add later ("BASH STEP")

exemplar_anots <- anots[(row.names(anots) %in% anots$Cluster_exemplar),] #get exemplar anots
exemplar_anots[exemplar_anots==''] <- "unknown function"

write.table(anots, "anots_exp_all_def_clusters.txt", sep = "\t", quote = F)

#BASH step:
#run get_anots_jumps_ALL.sh and create a table with OG codes (OG column) and reduced exemplar functions(red_funct column): Exp_ALL_exemplar_reduced_function_q0.txt


#("BASH STEP") Creat a table with the reduced exemplar function for every OG: "Exp_ALL_exemplar_reduced_function_q0.txt

red_funct <- read.table("Exp_ALL_exemplar_reduced_function.txt", sep = "\t", header = T, row.names = 1)

anots <- cbind.data.frame(anots, red_funct) #add this column to anots

anots[anots ==''] <- "unknown function" #replace NA for unknown function

#Heatmap lineage annotation: define palette for clusters, define gradient color for other anots, create the heatmap annotation (ha):
 	####shortcut to not recalculate all, import the file with anots:
anots <- read.table("anots_all_exp_reduced.txt", sep = "\t", row.names = 1, header = T)
anots[anots ==''] <- "unknown function" #replace NA for unknown function
linexcsim_all <- read.table("Exp_ALL_SimMat_NMDS.txt", h=T) #original matrix
linexcsim <- linexcsim_all[row.names(linexcsim_all) %in% anots$Cluster_exemplar]
exemplar_anots <- anots[(row.names(anots) %in% anots$Cluster_exemplar),] #get exemplar anots
exemplar_anots[exemplar_anots==''] <- "unknown function"
 	#####

cluster_col_pal <- colorRampPalette(c("#E67AA1","#5BBFF3","#962786","#6FBBC0","#304552","#7EB440","#1266B4"), bias = 1)(length(unique(sort(anots$Cluster_exemplar))))
cluster_col_pal <- setNames(colorRampPalette(brewer.pal(12,"Paired"))(length(unique(sort(anots$Cluster_exemplar)))),unique(sort(anots$Cluster_exemplar)))
cluster_col <- cluster_col_pal[(anots$Cluster_exemplar)]

function_col_pal <- colorRampPalette(c("#E67AA1","#5BBFF3","#962786","#6FBBC0","#304552","#7EB440","#1266B4"), bias = 1)(length(exemplar_anots$reduced_GO_term_function))
function_col_pal <- setNames(colorRampPalette(brewer.pal(8,"Dark2"))(length(exemplar_anots$reduced_GO_term_function)),(exemplar_anots$reduced_GO_term_function))
function_col <- function_col_pal[(exemplar_anots$reduced_GO_term_function)]


col = list(cluster_q0 = cluster_col)

ha <- HeatmapAnnotation(cluster_q0 = as.matrix(exemplar_anots$Cluster_exemplar), col = col)
          
h <- Heatmap(as.matrix(linexcsim), top_annotation = ha, row_split = as.matrix(anots$Cluster_exemplar),
        name = "Functional similarity",
        col = colorRamp2(c(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9), brewer.pal(n=9, name="YlGn")),
        column_title = "Exclusively Expanded Exemplar OGs",
        show_row_names = F,  show_column_names = T, column_names_gp = gpar(fontsize = 5),
        cluster_rows = TRUE, row_title_side = c("right"), row_title_gp = gpar(fontsize = 5), row_title_rot = 0, column_title_side = c("top"), column_title_gp = gpar(fontsize = 5),
        ) 
        
H <- h + Heatmap(as.matrix(anots$Cluster_exemplar), width = unit(5, "mm"), col = cluster_col, show_heatmap_legend = F) + Heatmap(as.matrix(anots$size), name = "size", width = unit(5, "mm"), col = (circlize::colorRamp2(c(2, 20), c("orange", "black")))) + Heatmap(as.matrix(anots$lineage), name = "lineage", width = unit(5, "mm"), col = c("Lepto1" = "#FF1414", "Lepto2" = "#402C00", "Lepto3" = "#FF8B1C", "Bides1" = "#003EBA", "Bides2" = "#66CCCC", "Hydro1" = "#038916")) + Heatmap(as.matrix(anots$exemplar_function), width = unit(5, "mm"), show_heatmap_legend = T, col = function_col)


pdf(H, file="H_EXP_ALL_redced_default.pdf", h=15, w=15)
H
dev.off()