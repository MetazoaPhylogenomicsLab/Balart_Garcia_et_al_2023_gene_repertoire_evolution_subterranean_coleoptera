while read BH
do
	grep "$BH" ../ALL_OGs_uniq_GO_Term_OK.txt || printf "\n"

done < con_all_exemplars.txt
 