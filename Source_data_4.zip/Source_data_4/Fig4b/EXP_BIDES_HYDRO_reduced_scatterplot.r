require(ggplot2)
library(dplyr)

# SimMatrix
linexcsim_all <- read.table("Exp_Bides_Hydro_SimMat.txt", h=T) #original matrix
to_drop <- read.table("Bides_Hydro_Exp_OGs_to_drop<2.txt", h=F) #OGs to drop in order to obtain the desired subset
linexcsim <- linexcsim_all[!row.names(linexcsim_all) %in% to_drop$V1] #remove columns
linexcsim <- linexcsim[!(row.names(linexcsim_all) %in% to_drop$V1),] #remove rows

EXP_BIDES_HYDRO_plot_table_sub <- EXP_BIDES_HYDRO_plot_table[!(row.names(EXP_BIDES_HYDRO_plot_table) %in% to_drop$V1),] #subset the annotation table for ploting


# Compute MMDS axes of distance matrix
xx <- cmdscale(as.matrix(as.dist(1 - linexcsim)), eig = TRUE, 
               k = 2) #METRIC MDS

# Build dataframe for plotting

# Exclusive expanded lineages lists for grouping/labeling
expExclusive_B1 <- read.table("bides1_exp_list_reduced.txt")$V1
expExclusive_B2 <- read.table("bides2_exp_list_reduced.txt")$V1
expExclusive_H1 <- read.table("hydro1_exp_list_reduced.txt")$V1

dfx <- cbind.data.frame(xx$points, "Lineage"=rep("aaa",nrow(xx$points)))
dfx[expExclusive_B1[expExclusive_B1%in%row.names(dfx)], "Lineage"] <- "B1"
dfx[expExclusive_B2[expExclusive_B2%in%row.names(dfx)], "Lineage"] <- "B2"
dfx[expExclusive_H1[expExclusive_H1%in%row.names(dfx)], "Lineage"] <- "H1"
colnames(dfx)[1:2] <-c("V1","V2")

head(dfx)

# Compute clusters using APC
require(apcluster)
cluster_apc_linexcsim <- apcluster(as.matrix(linexcsim), details=T, q=0) #on similarity matrix

# Formatting for plotting apc radiuses in ggplot2
clust_lines <- data.frame(xx$points, "Cluster_exemplar"=labels(cluster_apc_linexcsim) )
head(clust_lines)
clust_lines <- cbind.data.frame(clust_lines, clust_lines[clust_lines$Cluster_exemplar,c(1,2)])
clust_lines <- clust_lines[,3:5]
colnames(clust_lines)<-c("Cluster_exemplar", "X.start", "Y.start")

dfx <- cbind.data.frame(dfx, clust_lines)
EXP_BIDES_HYDRO_plot_table_sub$lineage <- NULL
EXP_BIDES_HYDRO_plot_table_sub$MDS.1 <- NULL
EXP_BIDES_HYDRO_plot_table_sub$MDS.2 <- NULL
dfx <- cbind.data.frame(dfx, EXP_BIDES_HYDRO_plot_table_sub)
head(dfx)

# Convex hulls
require(dplyr)
require(RColorBrewer)
hulls <- dfx[,1:4] %>%  group_by(Cluster_exemplar) %>% slice(chull(V1,V2))
hull_col_pal <- colorRampPalette(c("#E67AA1","#5BBFF3","#962786","#6FBBC0","#304552","#7EB440","#1266B4"), bias = 1)(length(unique(dfx$Cluster_exemplar)))
hull_col_pal <- setNames(colorRampPalette(brewer.pal(12,"Paired"))(length(unique(dfx$Cluster_exemplar))),unique(dfx$Cluster_exemplar))
hull_col <- hull_col_pal[hulls$Cluster_exemplar]

## PLOT
colors <- colorRampPalette(brewer.pal(12,"Paired"))(9) # indicate number of colors
colors <- sample(colors) #shuffle colors

p <- ggplot(dfx, aes(x = V1, y = V2, color = Lineage)) + 
  geom_polygon(data=hulls, aes(group=Cluster_exemplar),colour=NA,fill=hull_col, alpha=0.3, show.legend = F)+
  geom_segment(data=dfx, aes(x=X.start, y=Y.start, xend = V1, yend = V2),lwd=0.3, alpha=0.5) +
  theme_minimal() +
  scale_color_manual(values=colors) +
  scale_x_continuous(name = "MDS1") + 
  scale_y_continuous(name = "MDS2")  +
  geom_point(aes(size=size), alpha = 0.8) + 
  ggrepel::geom_label_repel(aes(label = reduced_GO_term_function, col=NULL), #example of labeling
                          data = subset(dfx, row.names(dfx)==Cluster_exemplar),
                          box.padding = grid::unit(1, "lines"),
                          size = 3, max.overlaps = 220, alpha=1) +
  geom_point(data = subset(dfx, row.names(dfx)==Cluster_exemplar), shape=5, size=7)


p

pdf(p, file="Bides_Hydro_expand_apclusters_q0_reduced<2.pdf", h=6, w=10)
p
dev.off()